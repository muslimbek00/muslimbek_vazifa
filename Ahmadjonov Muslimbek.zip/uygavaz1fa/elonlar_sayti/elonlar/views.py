from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, get_object_or_404
from .models import Kategoriya, Elon

def home(request):
    kategoriyalar = Kategoriya.objects.all()
    elonlar = Elon.objects.all()
    return render(request, 'elonlar/home.html', {'kategoriyalar': kategoriyalar, 'elonlar': elonlar})

def kategoriya_elonlar(request, kategoriya_id):
    kategoriya = get_object_or_404(Kategoriya, id=kategoriya_id)
    elonlar = Elon.objects.filter(kategoriya=kategoriya)
    return render(request, 'elonlar/kategoriya_elonlar.html', {'kategoriya': kategoriya, 'elonlar': elonlar})

def elon_detali(request, elon_id):
    elon = get_object_or_404(Elon, id=elon_id)
    return render(request, 'elonlar/elon_detali.html', {'elon': elon})
