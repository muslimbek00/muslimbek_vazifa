from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Kategoriya, Elon

@admin.register(Kategoriya)
class KategoriyaAdmin(admin.ModelAdmin):
    list_display = ['nom']
    search_fields = ['nom']

@admin.register(Elon)
class ElonAdmin(admin.ModelAdmin):
    list_display = ['sarlavha', 'kategoriya', 'sana']
    list_filter = ['kategoriya', 'sana']
    search_fields = ['sarlavha', 'mazmun']
