

from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('kategoriya/<int:kategoriya_id>/', views.kategoriya_elonlar, name='kategoriya_elonlar'),
    path('elon/<int:elon_id>/', views.elon_detali, name='elon_detali'),
]
